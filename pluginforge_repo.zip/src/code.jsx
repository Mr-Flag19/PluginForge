    /* ------------------------------------------------------------------ */
    /* Chat workspace (opens from every "Get Access" / "Get Started" link) */
    /* ------------------------------------------------------------------ */

    const ICONS = {
        plus: "M12 4.5v15m7.5-7.5h-15",
        search: "M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z",
        menu: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5",
        close: "M6 18L18 6M6 6l12 12",
        trash: "M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0",
        send: "M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3",
        logo: "M8 9l3 3-3 3m5 0h3",
        cube: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4",
        code: "M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4",
        lock: "M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z",
        back: "M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18",
        cog: "M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.325.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.241-.438.613-.43.992a7.723 7.723 0 010 .255c-.008.378.137.75.43.991l1.004.827c.424.35.534.955.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.47 6.47 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.019-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.991a6.932 6.932 0 010-.255c.007-.38-.138-.751-.43-.992l-1.004-.827a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z M15 12a3 3 0 11-6 0 3 3 0 016 0z",
        collapse: "M18.75 19.5l-7.5-7.5 7.5-7.5m-6 15L5.25 12l7.5-7.5",
        expand: "M11.25 4.5l7.5 7.5-7.5 7.5m-6-15l7.5 7.5-7.5 7.5",
        signout: "M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75"
    };

    function Icon({ d, className = "w-4 h-4", sw = 2 }) {
        return (
            <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={sw}>
                <path strokeLinecap="round" strokeLinejoin="round" d={d} />
            </svg>
        );
    }

    function LogoMark({ className = "h-7" }) {
        return (
            <svg className={`${className} w-auto shrink-0`} viewBox="200 252 827 627" fill="#ffffff" aria-hidden="true"><path d="M345.55 297.7 C345.68 308.49 343.88 339.94 347.18 348.42 C349.5 354.39 368.8 362.85 373.55 369.33 C375.49 371.99 379.8 407.78 380.54 413.67 L389.55 411.78 L389.05 357.72 L374.05 343.72 L374.05 288.39 C396.97 280.76 420.61 275.06 443.76 268.13 C453.85 265.11 471.13 258.11 480.9 257.27 C499.27 255.69 519.18 259.84 537.39 262.07 C562.52 265.15 587.78 267.53 612.95 270.26 C699.14 279.58 785.54 287.98 871.55 298.72 L871.05 344.97 L846.05 357.47 C846.05 370.28 846.64 382.94 847.55 395.72 L857.03 394.1 L858.05 368.66 C869.45 361.67 881.07 354.96 893.05 348.97 L893.55 307.88 L1022.55 324.72 L1022.55 392.64 C1011.15 396.07 1000.4 401.8 989.38 406.23 C975.14 411.97 958.94 416.84 946.06 425.3 L945.04 464.06 C922.3 474.25 897.68 479.98 875.05 490.41 L874.04 547.97 C866.85 551.57 849.78 560.17 842.07 559.15 C836.55 558.42 822.59 550.74 817.05 547.97 L816.04 500.11 C796.5 490.12 774.97 484.17 755.06 475.04 L754.03 444.25 C698.19 440.53 642.42 435.64 586.62 431.3 C570.83 430.08 555.04 428.93 539.26 427.61 C527.46 426.63 514.63 424.82 502.82 426.3 C495.75 427.18 488.52 431.13 481.68 433.15 C454.69 441.15 428.4 451.64 401.55 459.81 L401.55 503.45 C394.28 506.45 376.26 517.67 369.92 518.18 C363.07 518.73 355.91 515.14 349.58 512.9 C335.61 507.96 321.09 501.55 306.55 498.66 C306.48 493.92 307.05 465.43 305.51 463.31 C302.91 459.74 283.69 454.6 278.69 452.93 C254.05 444.72 229.4 436.21 204.55 428.63 L204.55 337.72 C238.09 329.34 271.27 318.82 304.49 309.21 C318.03 305.29 331.65 300.17 345.55 297.7 Z"/><path d="M319.05 694.39 L376.05 675.05 L377.05 540.47 L426.04 515.97 L427.06 474.38 C441.47 469.61 456.06 465.46 470.63 461.17 C477.15 459.25 484.01 456.21 490.76 455.3 C498.27 454.3 506.45 455.53 513.97 456 C529.46 456.96 544.87 458.27 560.38 458.84 C614.43 460.85 668.48 463.37 722.55 464.72 L723.06 489.06 L791.55 514.98 L792.05 556.02 L840.05 575.38 L840.55 681.72 L904.04 692.29 L904.55 731.72 L764.05 727.21 L763.04 616.22 L741.05 606.05 C740.92 598.48 741.39 553.22 739.76 549.74 C738.11 546.2 709.09 526.75 703.89 523.32 C697.72 519.24 691.41 514.52 685.48 510.03 C683.35 508.42 680.8 505.38 678.35 504.42 C673.35 502.46 650.78 503.24 643.72 502.76 C617.3 501 590.58 498.22 564.11 498.22 C559.33 498.22 553.01 497.13 548.41 498.43 C545.47 499.26 542.56 501.93 539.94 503.48 C526.94 511.2 514.57 520.71 501.05 527.47 L500.55 571.64 L469.05 582.39 L468.55 713.72 C452 713.2 434.09 711.38 417.62 713.3 C406.92 714.55 396.11 717.71 385.54 719.82 C363.24 724.28 340.93 728.6 318.55 732.6 Z"/><path d="M503.05 651.72 C517.55 637.22 533.33 623.06 549.55 610.57 L549.55 670.48 C552.99 668.04 567.08 656.03 568.73 652.77 C570.82 648.64 569.87 623.01 570.05 616.72 C579.71 607.06 588.58 596.72 597.94 586.85 C601.18 583.42 608.19 578.93 609.84 574.52 C611.7 569.54 610.47 533.29 610.55 525.23 C627.92 542.56 647.6 557.52 665.05 574.71 L666.05 636.75 C671.68 642.23 678.04 648.98 684.55 653.42 L684.55 606.23 L722.05 642.72 L722.55 689.72 L733.55 689.72 L733.55 724.72 C707.86 724.37 682.22 723.58 656.55 722.72 L656.05 680.72 C645.84 670.51 634.85 661.41 624.56 651.26 C624.43 656.86 625.67 668.53 623.86 673.48 C622.93 676.02 596.58 699.48 593.05 701.68 L592.55 719.72 C562.52 719.18 532.56 717.79 502.55 716.72 Z"/><path d="M248.05 746.34 L301.55 735.81 L301.55 803.45 L323.05 789.77 L323.55 747.72 C352.11 744.14 380.5 736.63 408.71 730.99 C417.92 729.14 427.72 725.75 437.11 725.25 C462.53 723.9 488.42 726.88 513.79 728.29 C564.03 731.08 614.27 734.62 664.55 736.72 L664.05 806.72 C657.09 813.68 648.54 821.62 640.05 826.6 L639.04 863.2 C596.66 865.21 554.31 867.57 511.95 869.92 C489.21 871.18 466.06 873.8 443.28 873.21 C434.31 872.97 425.12 871.22 416.2 870.18 C399.39 868.23 382.57 866.44 365.78 864.37 C326.41 859.54 286.91 855.64 247.55 850.72 Z"/><path d="M666.05 826.72 C671.44 821.33 677.68 817.08 683.05 811.72 L683.55 752.8 C692.98 749.96 702.26 742.97 711.88 741.32 C722.98 739.42 741.71 741.22 753.62 741.22 C790.93 741.22 828.24 742.14 865.55 742.72 L865.55 805.43 L890.55 817 L890.55 864.72 L665.55 864.72 Z"/><path d="M978.05 747.24 L978.55 851.72 L915.55 856.72 C915.49 849.89 916.41 805 914.51 802.32 C912.19 799.03 891.88 790.38 887.05 787.97 L886.55 743.72 Z"/></svg>
        );
    }


    const SUGGESTIONS = [
        { title: "Prison mine", text: "Create a prison mine plugin with rank progression and automated resets." },
        { title: "Lifesteal system", text: "Build a custom lifesteal system with heart crafting recipes and revive beacons." },
        { title: "Land claims", text: "Create a claims plugin with trust levels, sub-claims, and clean chat notifications." },
        { title: "RPG classes", text: "Build an RPG class selector with mana regeneration, custom spells, and cooldowns." }
    ];

    const CHAT_GROUPS = ["Today", "Yesterday", "Previous 7 days", "Older"];

    function groupFor(ms) {
        const startOfToday = new Date();
        startOfToday.setHours(0, 0, 0, 0);
        const day = 24 * 60 * 60 * 1000;
        const today = startOfToday.getTime();
        if (ms >= today) return "Today";
        if (ms >= today - day) return "Yesterday";
        if (ms >= today - 7 * day) return "Previous 7 days";
        return "Older";
    }

    const ID_CHARS = 'abcdefghijklmnopqrstuvwxyz0123456789';
    const ID_FROM_PATH = /\/([a-z0-9]{16})\/?$/;

    // Placeholder ID shown for a moment until the server assigns the real one
    function newProjectId() {
        let id = '';
        while (id.length < 16) {
            const bytes = new Uint8Array(32);
            crypto.getRandomValues(bytes);
            for (const b of bytes) {
                if (b < 252 && id.length < 16) id += ID_CHARS[b % 36];
            }
        }
        return id;
    }

    function getIdFromPath() {
        const m = window.location.pathname.match(ID_FROM_PATH);
        return m ? m[1] : null;
    }

    // The folder this page lives in, e.g. /code/ (works for any folder name)
    function getBasePath() {
        const path = window.location.pathname.replace(/\/index\.html$/, '').replace(/\/[a-z0-9]{16}\/?$/, '').replace(/\/+$/, '');
        return path + '/';
    }

    function navigateTo(id, replace) {
        try {
            const base = getBasePath();
            const url = id ? base + id : base;
            if (window.location.pathname === url) return;
            window.history[replace ? 'replaceState' : 'pushState']({}, '', url);
        } catch (e) {}
    }

    // ---- Talking to the server (/api/projects). Your Discord sign-in cookie is sent automatically. ----
    async function api(path, method, body) {
        try {
            const r = await fetch('/api/projects' + path, {
                method,
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'x-pf-request': '1' },
                body: body ? JSON.stringify(body) : undefined
            });
            let data = null;
            try { data = await r.json(); } catch (e) {}
            return { ok: r.ok, status: r.status, data };
        } catch (e) {
            return { ok: false, status: 0, data: null };
        }
    }


    const initialsOf = (name) => (String(name || '?').trim().split(/\s+/).slice(0, 2).map((w) => w.charAt(0)).join('') || '?').toUpperCase();

    function DiscordMark() {
        return (
            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.011c3.927 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
            </svg>
        );
    }

    // Discord profile picture, with initials if there is none or it fails to load
    function Avatar({ user }) {
        const [failed, setFailed] = React.useState(false);
        if (user.avatar && !failed) {
            return <img src={user.avatar} alt="" onError={() => setFailed(true)} className="w-9 h-9 rounded-md shrink-0 bg-[#3A3D42] border border-[#4b4f56] object-cover" />;
        }
        return (
            <div className="w-9 h-9 rounded-md bg-[#3A3D42] border border-[#4b4f56] flex items-center justify-center text-sm font-semibold text-[#f4f4f5] shrink-0" aria-hidden="true">{initialsOf(user.name)}</div>
        );
    }

    function LoadingScreen() {
        return (
            <div className="h-full flex items-center justify-center bg-[#26282B]" role="status" aria-label="Loading">
                <div className="animate-pulse"><LogoMark className="h-10" /></div>
            </div>
        );
    }

    function SignInScreen({ message, unavailable }) {
        const next = encodeURIComponent(window.location.pathname);
        return (
            <div className="min-h-full h-full relative flex flex-col bg-[#26282B] text-[#f4f4f5] font-sans overflow-y-auto">
                <div className="fixed inset-0 bg-grid-pattern opacity-30 pointer-events-none"></div>
                <header className="relative z-10 py-5 px-6 sm:px-8 border-b border-[#3A3D42] bg-[#26282B]/90 backdrop-blur-md">
                    <div className="max-w-6xl mx-auto flex items-center justify-between">
                        <a href="/" className="flex items-center gap-2.5">
                            <LogoMark />
                            <span className="font-bold tracking-tight text-base">PluginForge</span>
                        </a>
                        <a href="/" className="text-[#a1a1aa] hover:text-[#f4f4f5] text-xs flex items-center gap-1.5 transition-colors">
                            <Icon d={ICONS.back} className="w-3.5 h-3.5" />
                            Back to site
                        </a>
                    </div>
                </header>
                <main className="relative z-10 flex-1 flex items-center justify-center px-6 py-12">
                    <div className="w-full max-w-md text-center">
                        <div className="flex justify-center"><LogoMark className="h-10" /></div>
                        <h1 className="mt-6 text-2xl sm:text-3xl font-bold tracking-tight">Sign in to start building</h1>
                        <p className="mt-3 text-xs sm:text-sm text-[#a1a1aa] leading-relaxed">
                            Your projects are saved to your Discord account, so you can pick them up on any device.
                        </p>
                        <div className="mt-8 bg-[#2C2E31] border border-[#3A3D42] rounded-2xl p-3 shadow-xl">
                            {unavailable ? (
                                <div role="alert" className="px-3 py-4 text-sm text-[#a1a1aa] leading-relaxed">
                                    Sign in isn't available right now. Please try again later.
                                </div>
                            ) : (
                                <a
                                    href={'/api/auth/login?next=' + next}
                                    className="w-full flex items-center justify-center gap-2.5 bg-[#5865F2] hover:bg-[#4752C4] text-white text-sm font-semibold py-2.5 rounded-lg transition-colors"
                                >
                                    <DiscordMark />
                                    Continue with Discord
                                </a>
                            )}
                        </div>
                        <p role="alert" className="mt-4 min-h-[1rem] text-xs text-[#a1a1aa] leading-relaxed">{message}</p>
                        <p className="mt-6 text-[11px] text-[#71717a] leading-relaxed">
                            PluginForge only reads your Discord username, display name, profile picture and account ID. It never sees your password.
                        </p>
                    </div>
                </main>
            </div>
        );
    }

    function FileRow({ f }) {
        return (
            <div className="p-4 flex items-center gap-3.5 hover:bg-[#3A3D42]/30 transition-colors">
                <div className="text-[#a1a1aa] shrink-0">
                    <Icon d={f.locked ? ICONS.code : ICONS.cube} className="w-5 h-5" sw={1.5} />
                </div>
                <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-2 min-w-0">
                            <span className="font-mono text-sm font-medium text-[#f4f4f5] truncate">{f.name}</span>
                            {f.size && <span className="text-[11px] text-[#71717a] font-mono">{f.size}</span>}
                            {f.locked && <Icon d={ICONS.lock} className="w-3.5 h-3.5 text-[#a1a1aa] shrink-0" />}
                        </div>
                        {f.locked && (
                            <span className="text-[11px] font-medium text-[#a1a1aa] bg-[#26282B] border border-[#3A3D42] px-2.5 py-0.5 rounded">
                                Iron & Diamond tiers
                            </span>
                        )}
                    </div>
                    <p className="text-xs text-[#a1a1aa] mt-0.5">{f.desc}</p>
                </div>
            </div>
        );
    }

    function UserMessage({ m }) {
        return (
            <div className="flex justify-end">
                <div className="max-w-[88%] sm:max-w-[80%] bg-[#2C2E31] border border-[#3A3D42] rounded-2xl rounded-tr-md px-4 py-3 text-sm text-[#f4f4f5] leading-relaxed whitespace-pre-wrap break-words">
                    {m.text}
                </div>
            </div>
        );
    }

    function AssistantMessage({ m }) {
        return (
            <div className="flex gap-3.5">
                <div className="mt-0.5"><LogoMark /></div>
                <div className="min-w-0 flex-1 space-y-4 text-sm text-[#e4e4e7] leading-relaxed">
                    {m.text && <p>{m.text}</p>}
                    {m.points && (
                        <ul className="space-y-2 text-[#a1a1aa]">
                            {m.points.map((p, i) => (
                                <li key={i} className="flex gap-2">
                                    <span className="text-[#71717a] font-mono">•</span>
                                    <span className="min-w-0">{p}</span>
                                </li>
                            ))}
                        </ul>
                    )}
                    {m.commands && (
                        <div className="flex flex-wrap gap-1.5">
                            {m.commands.map((c) => (
                                <span key={c} className="font-mono text-[11px] bg-[#2C2E31] border border-[#3A3D42] px-2 py-1 rounded-md text-[#f4f4f5]">{c}</span>
                            ))}
                        </div>
                    )}
                    {m.files && (
                        <div className="bg-[#2C2E31] border border-[#3A3D42] rounded-lg overflow-hidden divide-y divide-[#3A3D42]">
                            {m.files.map((f) => <FileRow key={f.name} f={f} />)}
                        </div>
                    )}
                    {m.after && <p>{m.after}</p>}
                </div>
            </div>
        );
    }

    function TypingIndicator() {
        return (
            <div className="flex gap-3.5 items-center" aria-label="PluginForge is replying">
                <LogoMark />
                <div className="flex items-center gap-1.5">
                    {[0, 1, 2].map((i) => (
                        <span key={i} className="w-1.5 h-1.5 rounded-full bg-[#a1a1aa] animate-pulse" style={{ animationDelay: `${i * 200}ms` }}></span>
                    ))}
                </div>
            </div>
        );
    }

    function PricingModal({ onClose }) {
        const [isAnnual, setIsAnnual] = React.useState(false);
        const [notice, setNotice] = React.useState('');

        React.useEffect(() => {
            const onKey = (e) => { if (e.key === 'Escape') onClose(); };
            window.addEventListener('keydown', onKey);
            return () => window.removeEventListener('keydown', onKey);
        }, []);

        const choose = () => setNotice("Billing isn't connected yet, so plans can't be changed in this preview.");

        return (
            <div className="fixed inset-0 z-[60] overflow-y-auto bg-black/55 backdrop-blur-xl" onClick={onClose}>
                <button
                    onClick={onClose}
                    className="fixed right-4 z-[61] text-[#a1a1aa] hover:text-[#f4f4f5] p-2 rounded-full bg-[#2C2E31]/80 border border-[#3A3D42] backdrop-blur-md transition-colors"
                    style={{ top: 'calc(env(safe-area-inset-top, 0px) + 16px)' }}
                    aria-label="Close pricing"
                >
                    <Icon d={ICONS.close} className="w-5 h-5" />
                </button>

                <div className="min-h-full flex items-center justify-center px-4 py-20">
                    <div
                        role="dialog"
                        aria-modal="true"
                        aria-label="Pricing tiers"
                        onClick={(e) => e.stopPropagation()}
                        className="w-full max-w-4xl"
                    >
                        <div className="text-center">
                            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-[#f4f4f5]">Pricing Tiers</h2>
                            <p className="mt-2 text-xs sm:text-sm text-[#a1a1aa]">You are on the Stone Tier.</p>
                        </div>

                        {/* Monthly / Annual Billing Toggle */}
                        <div className="mt-6 mb-10 flex justify-center">
                            <div className="inline-flex items-center gap-3 bg-[#2C2E31]/80 border border-[#3A3D42] backdrop-blur-md rounded-full pl-4 pr-3 py-1.5">
                                <span className={`text-xs font-medium transition-colors ${!isAnnual ? 'text-[#f4f4f5]' : 'text-[#a1a1aa]'}`}>
                                    Monthly
                                </span>
                                <button
                                    onClick={() => setIsAnnual(!isAnnual)}
                                    className="w-12 h-6 bg-[#26282B] border border-[#3A3D42] rounded-full p-0.5 relative transition-colors focus:outline-none"
                                    aria-label="Toggle billing cycle"
                                >
                                    <div className={`w-4 h-4 bg-[#f4f4f5] rounded-full transition-transform duration-200 ease-in-out ${isAnnual ? 'translate-x-6' : 'translate-x-0'}`}></div>
                                </button>
                                <span className={`text-xs font-medium transition-colors ${isAnnual ? 'text-[#f4f4f5]' : 'text-[#a1a1aa]'}`}>
                                    Annual
                                </span>
                                <span className="text-[10px] font-mono text-[#26282B] bg-[#f4f4f5] font-bold px-2 py-0.5 rounded-full">
                                    Save 20%
                                </span>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
                            <div className="bg-[#2C2E31] border border-[#3A3D42] rounded-xl p-6 flex flex-col justify-between shadow-2xl shadow-black/40">
                                <div>
                                    <div className="text-sm font-medium text-[#f4f4f5]">Stone Tier</div>
                                    <div className="mt-3 text-2xl sm:text-3xl font-semibold text-[#f4f4f5]">$0</div>
                                    <ul className="mt-6 space-y-3 text-xs text-[#a1a1aa] border-t border-[#3A3D42] pt-4">
                                        <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> 5 plugin generations/day</li>
                                        <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> Compiled .jar download</li>
                                        <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> Automated error self-healing</li>
                                    </ul>
                                </div>
                                <div className="mt-6 pt-4">
                                    <div className="w-full text-center bg-[#26282B] border border-[#3A3D42] text-[#71717a] text-xs font-semibold py-2 rounded">
                                        Current plan
                                    </div>
                                </div>
                            </div>

                            <div className="bg-[#2C2E31] border border-[#f4f4f5]/50 rounded-xl p-6 flex flex-col justify-between relative md:scale-105 md:z-10 shadow-2xl shadow-black/60">
                                <div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm font-semibold text-[#f4f4f5]">Iron Tier</span>
                                        <span className="text-[10px] font-mono text-[#26282B] bg-[#f4f4f5] px-2.5 py-0.5 rounded-full font-semibold">Popular</span>
                                    </div>
                                    <div className="mt-3 text-2xl sm:text-3xl font-semibold text-[#f4f4f5]">
                                        {isAnnual ? "$7.99" : "$9.99"}
                                        <span className="text-xs font-normal text-[#a1a1aa]">/mo</span>
                                    </div>
                                    {isAnnual && (
                                        <div className="text-[11px] text-[#a1a1aa] mt-1 font-mono">Billed annually ($95.88/yr)</div>
                                    )}
                                    <div className="mt-6 border-t border-[#3A3D42] pt-4">
                                        <p className="text-[11px] text-[#e4e4e7] font-medium mb-3">
                                            Everything in Stone Tier, plus:
                                        </p>
                                        <ul className="space-y-3 text-xs text-[#a1a1aa]">
                                            <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> 250 generations/mo</li>
                                            <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> Full Java source code access</li>
                                            <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> Compile checking</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="mt-6 pt-4">
                                    <button onClick={choose} className="w-full text-center bg-[#f4f4f5] hover:bg-[#e4e4e7] text-[#26282B] text-xs font-semibold py-2 rounded transition-colors">
                                        Get Access
                                    </button>
                                </div>
                            </div>

                            <div className="bg-[#2C2E31] border border-[#3A3D42] rounded-xl p-6 flex flex-col justify-between shadow-2xl shadow-black/40">
                                <div>
                                    <div className="text-sm font-medium text-[#f4f4f5]">Diamond Tier</div>
                                    <div className="mt-3 text-2xl sm:text-3xl font-semibold text-[#f4f4f5]">
                                        {isAnnual ? "$15.99" : "$19.99"}
                                        <span className="text-xs font-normal text-[#a1a1aa]">/mo</span>
                                    </div>
                                    {isAnnual && (
                                        <div className="text-[11px] text-[#a1a1aa] mt-1 font-mono">Billed annually ($191.88/yr)</div>
                                    )}
                                    <div className="mt-6 border-t border-[#3A3D42] pt-4">
                                        <p className="text-[11px] text-[#e4e4e7] font-medium mb-3">
                                            Everything in Iron Tier, plus:
                                        </p>
                                        <ul className="space-y-3 text-xs text-[#a1a1aa]">
                                            <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> 1000 generations/mo</li>
                                            <li className="flex items-center gap-2"><span className="text-[#f4f4f5] font-mono">•</span> Project storage & history</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="mt-6 pt-4">
                                    <button onClick={choose} className="w-full text-center bg-[#26282B] hover:bg-[#3A3D42] border border-[#3A3D42] text-[#f4f4f5] text-xs font-semibold py-2 rounded transition-colors">
                                        Get Access
                                    </button>
                                </div>
                            </div>
                        </div>

                        <p role="status" className="mt-10 min-h-[1rem] text-center text-xs text-[#a1a1aa]">{notice}</p>
                    </div>
                </div>
            </div>
        );
    }

    // "5h 12m", "2d 3h", "under a minute"
    function timeUntil(ms) {
        const mins = Math.ceil(ms / 60000);
        if (mins < 1) return 'under a minute';
        const d = Math.floor(mins / 1440), h = Math.floor((mins % 1440) / 60), m = mins % 60;
        if (d > 0) return d + 'd ' + h + 'h';
        if (h > 0) return h + 'h ' + m + 'm';
        return m + 'm';
    }

    // The tier and prompts left. Hover (or focus) it to see when the prompts refill.
    function UsageMeter({ usage }) {
        const [now, setNow] = React.useState(Date.now());
        React.useEffect(() => {
            const t = setInterval(() => setNow(Date.now()), 15000);
            return () => clearInterval(t);
        }, []);
        const total = Math.max(usage.limit, usage.left);
        let headline, detail;
        if (!usage.resetsAt) {
            headline = usage.used > 0 ? 'Refilling' : 'Prompts are full';
            detail = 'Your 24 hour timer starts when you send your next prompt.';
        } else if (usage.resetsAt <= now) {
            headline = 'Refilling now';
            detail = 'Your prompts are being topped up.';
        } else {
            headline = 'Refills in ' + timeUntil(usage.resetsAt - now);
            detail = new Date(usage.resetsAt).toLocaleString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZoneName: 'short' });
        }
        return (
            <div className="usage-wrap" tabIndex={0} aria-describedby="usage-tip">
                <div role="tooltip" id="usage-tip" className="usage-tip bg-[#26282B] border border-[#3A3D42] rounded-lg shadow-xl px-3 py-2.5">
                    <div className="text-xs font-medium text-[#f4f4f5]">{headline}</div>
                    <div className="mt-0.5 text-xs text-[#a1a1aa]">{detail}</div>
                </div>
                <div className="flex items-baseline justify-between gap-3">
                    <span className="text-[13px] font-semibold text-[#f4f4f5]">{usage.tierName} Tier</span>
                    <span className="text-[13px] font-semibold text-[#f4f4f5] tabular-nums">{usage.left} / {total}</span>
                </div>
                <div className="mt-2 h-1.5 rounded-full bg-[#3A3D42] overflow-hidden">
                    <div className="h-full bg-[#f4f4f5] rounded-full" style={{ width: Math.max(0, Math.min(100, (usage.left / total) * 100)) + '%' }}></div>
                </div>
                <div className="mt-1.5 text-xs text-[#a1a1aa]">prompts left{usage.period === 'day' ? '' : ' this month'}</div>
            </div>
        );
    }

    // When the Discord account was made. A Discord ID encodes the creation time.
    function discordCreated(id) {
        try { return new Date(Number((BigInt(id) >> 22n) + 1420070400000n)); } catch (e) { return null; }
    }

    function useEscape(onClose) {
        React.useEffect(() => {
            const onKey = (e) => { if (e.key === 'Escape') onClose(); };
            window.addEventListener('keydown', onKey);
            return () => window.removeEventListener('keydown', onKey);
        }, []);
    }

    function ModalShell({ label, onClose, children }) {
        useEscape(onClose);
        return (
            <div className="fixed inset-0 z-[60] overflow-y-auto bg-black/55 backdrop-blur-xl" onClick={onClose}>
                <div className="min-h-full flex items-center justify-center p-4">
                    <div role="dialog" aria-modal="true" aria-label={label} onClick={(e) => e.stopPropagation()} className="relative w-full max-w-sm bg-[#2C2E31] border border-[#3A3D42] rounded-2xl shadow-2xl overflow-hidden">
                        <button onClick={onClose} autoFocus className="absolute right-3 top-3 text-[#a1a1aa] hover:text-[#f4f4f5] p-1.5 rounded-md hover:bg-[#3A3D42]/60 transition-colors" aria-label="Close">
                            <Icon d={ICONS.close} className="w-4 h-4" />
                        </button>
                        {children}
                    </div>
                </div>
            </div>
        );
    }

    function Row({ label, children }) {
        return (
            <div className="px-5 py-3 flex items-start justify-between gap-4 text-sm">
                <dt className="text-[#a1a1aa] shrink-0">{label}</dt>
                <dd className="text-[#f4f4f5] text-right min-w-0 break-words">{children}</dd>
            </div>
        );
    }

    function ProfileModal({ user, chats, onClose, onSignOut }) {
        const [failed, setFailed] = React.useState(false);
        const [copied, setCopied] = React.useState(false);
        const u = user.usage;
        const created = discordCreated(user.id);
        const big = user.avatar ? user.avatar.replace('size=64', 'size=256') : '';
        const copyId = () => {
            try {
                navigator.clipboard.writeText(user.id).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1500); }).catch(() => {});
            } catch (e) {}
        };
        let promptsText = 'Unavailable';
        let refillText = '';
        if (u) {
            promptsText = u.left + ' of ' + Math.max(u.limit, u.left) + (u.period === 'day' ? '' : ' this month');
            if (u.resetsAt && u.resetsAt > Date.now()) refillText = 'Refills in ' + timeUntil(u.resetsAt - Date.now());
        }
        return (
            <ModalShell label="Your profile" onClose={onClose}>
                <div className="px-5 pt-6 pb-5 flex items-center gap-4">
                    {big && !failed
                        ? <img src={big} alt="" onError={() => setFailed(true)} className="w-16 h-16 rounded-xl shrink-0 bg-[#3A3D42] border border-[#4b4f56] object-cover" />
                        : <div className="w-16 h-16 rounded-xl bg-[#3A3D42] border border-[#4b4f56] flex items-center justify-center text-xl font-semibold text-[#f4f4f5] shrink-0" aria-hidden="true">{initialsOf(user.name)}</div>}
                    <div className="min-w-0 pr-6">
                        <div className="text-lg font-semibold text-[#f4f4f5] truncate">{user.name}</div>
                        <div className="text-sm text-[#a1a1aa] truncate">{user.username ? '@' + user.username : 'Discord account'}</div>
                    </div>
                </div>
                <dl className="border-t border-[#3A3D42] divide-y divide-[#3A3D42]">
                    <Row label="Email">{user.email || <span className="text-[#a1a1aa]">Not shared. Sign out and back in to show it.</span>}</Row>
                    <Row label="Username">{user.username ? '@' + user.username : 'Not available'}</Row>
                    <Row label="Discord ID">
                        <span className="tabular-nums">{user.id}</span>
                        <button onClick={copyId} className="ml-2 text-xs text-[#a1a1aa] hover:text-[#f4f4f5] underline underline-offset-2">{copied ? 'Copied' : 'Copy'}</button>
                    </Row>
                </dl>
                <dl className="border-t border-[#3A3D42] divide-y divide-[#3A3D42]">
                    <Row label="Plan">{u ? u.tierName + ' Tier' : 'Unavailable'}</Row>
                    <Row label="Prompts left">
                        <div>{promptsText}</div>
                        {refillText && <div className="text-xs text-[#a1a1aa] mt-0.5">{refillText}</div>}
                    </Row>
                    <Row label="Projects">{chats.length}</Row>
                    <Row label="On Discord since">{created ? created.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : 'Unknown'}</Row>
                </dl>
                <div className="p-4 border-t border-[#3A3D42]">
                    <button onClick={onSignOut} className="w-full flex items-center justify-center gap-2 text-sm font-medium text-[#f4f4f5] bg-[#26282B] hover:bg-[#3A3D42] border border-[#3A3D42] py-2.5 rounded-lg transition-colors">
                        <Icon d={ICONS.signout} className="w-4 h-4" />
                        Sign out
                    </button>
                </div>
            </ModalShell>
        );
    }

    function SettingsModal({ user, onClose, onSignOut, onPlans }) {
        return (
            <ModalShell label="Settings" onClose={onClose}>
                <div className="px-5 pt-5 pb-4">
                    <h2 className="text-base font-semibold text-[#f4f4f5] flex items-center gap-2"><Icon d={ICONS.cog} className="w-4 h-4" sw={1.75} />Settings</h2>
                </div>
                <dl className="border-t border-[#3A3D42] divide-y divide-[#3A3D42]">
                    <Row label="Signed in as">{user.name}{user.username ? <span className="text-[#a1a1aa]"> (@{user.username})</span> : null}</Row>
                    <Row label="Plan">
                        {user.usage ? user.usage.tierName + ' Tier' : 'Unavailable'}
                        <button onClick={onPlans} className="ml-2 text-xs text-[#a1a1aa] hover:text-[#f4f4f5] underline underline-offset-2">View plans</button>
                    </Row>
                    <Row label="Website"><a href="/" className="text-[#f4f4f5] hover:underline underline-offset-2">Back to PluginForge home</a></Row>
                </dl>
                <div className="p-4 border-t border-[#3A3D42]">
                    <button onClick={onSignOut} className="w-full flex items-center justify-center gap-2 text-sm font-medium text-[#f4f4f5] bg-[#26282B] hover:bg-[#3A3D42] border border-[#3A3D42] py-2.5 rounded-lg transition-colors">
                        <Icon d={ICONS.signout} className="w-4 h-4" />
                        Sign out
                    </button>
                </div>
            </ModalShell>
        );
    }

    function ChatApp({ user, chats, setChats, activeId, setActiveId, loadingProject, onSignOut, onSessionExpired, onUsage }) {
        const [sidebarOpen, setSidebarOpen] = React.useState(false);
        // Desktop only: shrink the sidebar to a narrow rail with just the profile picture and the projects
        const [collapsed, setCollapsed] = React.useState(() => {
            try { return window.localStorage.getItem('pf_sidebar') === 'collapsed'; } catch (e) { return false; }
        });
        const [showProfile, setShowProfile] = React.useState(false);
        const [showSettings, setShowSettings] = React.useState(false);
        const toggleCollapsed = () => {
            const next = !collapsed;
            setCollapsed(next);
            try { window.localStorage.setItem('pf_sidebar', next ? 'collapsed' : 'open'); } catch (e) {}
        };
        const [query, setQuery] = React.useState('');
        const [draft, setDraft] = React.useState('');
        const [pendingId, setPendingId] = React.useState(null);
        const [showPricing, setShowPricing] = React.useState(() => window.location.hash === '#pricing');
        const [copied, setCopied] = React.useState(false);
        const [notice, setNotice] = React.useState('');
        const endRef = React.useRef(null);
        const taRef = React.useRef(null);

        const active = chats.find((c) => c.id === activeId) || null;
        const urlId = getIdFromPath();
        const missingId = !active && !loadingProject && urlId && !chats.some((c) => c.id === urlId) ? urlId : null;
        const messages = active && active.messages ? active.messages : [];
        const isPending = pendingId !== null && pendingId === activeId;
        const needle = query.trim().toLowerCase();

        const groups = CHAT_GROUPS
            .map((g) => ({
                name: g,
                items: chats
                    .filter((c) => groupFor(c.updatedAt || Date.now()) === g && c.title.toLowerCase().includes(needle))
                    .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))
            }))
            .filter((g) => g.items.length > 0);

        // The sidebar list only has titles, so fetch the conversation when a project is opened
        const needsMessages = Boolean(active) && !active.messages && !active.loadFailed;
        React.useEffect(() => {
            if (!needsMessages) return;
            let cancelled = false;
            const id = active.id;
            api('/' + id, 'GET').then((res) => {
                if (cancelled) return;
                if (res.ok && res.data && Array.isArray(res.data.messages)) {
                    setChats((prev) => prev.map((c) => (c.id === id ? { ...c, messages: res.data.messages } : c)));
                } else if (res.status === 401) {
                    onSessionExpired();
                } else {
                    setChats((prev) => prev.map((c) => (c.id === id ? { ...c, messages: [], loadFailed: true } : c)));
                }
            });
            return () => { cancelled = true; };
        }, [activeId, needsMessages]);

        React.useEffect(() => {
            if (endRef.current) endRef.current.scrollIntoView({ block: 'end' });
        }, [messages.length, isPending, activeId]);

        React.useEffect(() => {
            const el = taRef.current;
            if (!el) return;
            el.style.height = 'auto';
            el.style.height = Math.min(el.scrollHeight, 160) + 'px';
        }, [draft]);

        const selectChat = (id) => {
            setNotice('');
            setActiveId(id);
            navigateTo(id);
            setSidebarOpen(false);
        };

        const newChat = () => {
            setNotice('');
            setActiveId(null);
            navigateTo(null);
            setSidebarOpen(false);
            if (taRef.current) taRef.current.focus();
        };

        const deleteChat = async (id) => {
            setNotice('');
            const res = await api('/' + id, 'DELETE');
            if (res.status === 401) return onSessionExpired();
            if (!res.ok && res.status !== 404) {
                setNotice("Couldn't delete this project. Check your connection and try again.");
                return;
            }
            setChats((prev) => prev.filter((c) => c.id !== id));
            if (activeId === id) {
                setActiveId(null);
                navigateTo(null, true);
            }
        };

        // The server is the only thing that decides what a prompt costs and what the reply is.
        // This page sends just the new prompt, then shows what the server sends back.
        const refusal = (res) => {
            const d = res.data || {};
            if (res.status === 429 && d.code === 'quota') return 'You have no prompts left. ' + (d.usage && d.usage.resetsAt ? 'They refill ' + new Date(d.usage.resetsAt).toLocaleString() + '.' : 'See Plans for more.');
            if (res.status === 429 && d.code === 'project_limit') return 'You have reached the limit of 200 projects. Delete one to make a new one.';
            if (res.status === 429) return 'You are sending prompts too quickly. Try again in ' + (d.retryAfter || 'a few') + ' seconds.';
            return d.error || "Couldn't send your prompt. Check your connection and try again. Your message is still in the box.";
        };

        const send = async () => {
            const text = draft.trim();
            if (!text || pendingId) return;
            const userMsg = { role: 'user', text };
            setNotice('');
            setDraft('');

            let id = activeId;
            const title = active ? active.title : (text.length > 44 ? text.slice(0, 44).trimEnd() + '…' : text);

            if (!active) {
                // Show the chat straight away, then swap in the ID the server assigns
                const tempId = newProjectId();
                setChats((prev) => [{ id: tempId, title, updatedAt: Date.now(), messages: [userMsg] }, ...prev]);
                setActiveId(tempId);
                navigateTo(tempId);
                setPendingId(tempId);
                const created = await api('', 'POST', { title, prompt: text });
                if (!created.ok) {
                    // Nothing was saved or charged, so take the chat back out and give the message back
                    setChats((prev) => prev.filter((c) => c.id !== tempId));
                    setActiveId(null);
                    navigateTo(null, true);
                    setPendingId(null);
                    setDraft(text);
                    if (created.status === 401) return onSessionExpired();
                    if (created.data && created.data.usage) onUsage(created.data.usage);
                    setNotice(refusal(created));
                    return;
                }
                id = created.data.id;
                if (created.data.usage) onUsage(created.data.usage);
                setChats((prev) => prev.map((c) => (c.id === tempId ? { ...c, id, title: created.data.title || title, messages: created.data.messages, updatedAt: created.data.updatedAt || Date.now() } : c)));
                setActiveId(id);
                navigateTo(id, true);
                setPendingId(null);
                return;
            }

            setChats((prev) => prev.map((c) => (c.id === id ? { ...c, messages: [...c.messages, userMsg], updatedAt: Date.now() } : c)));
            setPendingId(id);
            const sent = await api('/' + id, 'POST', { prompt: text });
            setPendingId(null);
            if (!sent.ok) {
                // Nothing was saved or charged: remove the prompt from the screen and give it back
                setChats((prev) => prev.map((c) => (c.id === id ? { ...c, messages: c.messages.slice(0, -1) } : c)));
                setDraft(text);
                if (sent.status === 401) return onSessionExpired();
                if (sent.data && sent.data.usage) onUsage(sent.data.usage);
                setNotice(refusal(sent));
                return;
            }
            const added = (sent.data && sent.data.messages) || [];
            setChats((prev) => prev.map((c) => (c.id === id ? { ...c, messages: [...c.messages.slice(0, -1), ...added], updatedAt: sent.data.updatedAt || Date.now() } : c)));
            if (sent.data && sent.data.usage) onUsage(sent.data.usage);
        };

        const copyId = () => {
            if (!active) return;
            try {
                navigator.clipboard.writeText(active.id).then(() => {
                    setCopied(true);
                    setTimeout(() => setCopied(false), 1500);
                }).catch(() => {});
            } catch (e) {}
        };

        const onKeyDown = (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                send();
            }
        };

        return (
            <div className="h-full flex bg-[#26282B] text-[#f4f4f5] font-sans overflow-hidden relative">
                {showPricing && <PricingModal onClose={() => setShowPricing(false)} />}
                {showProfile && <ProfileModal user={user} chats={chats} onClose={() => setShowProfile(false)} onSignOut={onSignOut} />}
                {showSettings && <SettingsModal user={user} onClose={() => setShowSettings(false)} onSignOut={onSignOut} onPlans={() => { setShowSettings(false); setShowPricing(true); }} />}

                {/* Mobile backdrop */}
                {sidebarOpen && (
                    <div
                        className="fixed inset-0 bg-black/60 z-40 md:hidden"
                        onClick={() => setSidebarOpen(false)}
                    ></div>
                )}

                {/* Sidebar */}
                <aside
                    className={`fixed md:relative inset-y-0 left-0 z-50 w-72 max-w-[85vw] ${collapsed ? 'md:w-16' : ''} shrink-0 flex flex-col bg-[#2C2E31] border-r border-[#3A3D42] transform transition-transform duration-200 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}
                    style={{ paddingTop: 'env(safe-area-inset-top, 0px)', paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
                >
                  <div className={collapsed ? 'md:hidden flex flex-col flex-1 min-h-0' : 'flex flex-col flex-1 min-h-0'}>
                    <div className="px-4 py-4 flex items-center justify-between">
                        <a href="/" className="flex items-center gap-2.5">
                            <LogoMark />
                            <span className="font-bold tracking-tight text-base text-[#f4f4f5]">PluginForge</span>
                        </a>
                        <button
                            onClick={() => setSidebarOpen(false)}
                            className="md:hidden text-[#a1a1aa] hover:text-[#f4f4f5] p-1.5 rounded-md border border-[#3A3D42] bg-[#26282B] transition-colors"
                            aria-label="Close sidebar"
                        >
                            <Icon d={ICONS.close} className="w-4 h-4" />
                        </button>
                    </div>

                    <div className="px-3 space-y-2.5">
                        <button
                            onClick={newChat}
                            className="w-full bg-[#f4f4f5] hover:bg-[#e4e4e7] text-[#26282B] text-xs font-semibold py-2 rounded transition-colors flex items-center justify-center gap-1.5"
                        >
                            <Icon d={ICONS.plus} className="w-3.5 h-3.5" sw={2.5} />
                            New plugin
                        </button>
                        <div className="flex items-center gap-2 bg-[#26282B] border border-[#3A3D42] focus-within:border-[#71717a] rounded-md px-2.5 py-1.5 transition-colors">
                            <Icon d={ICONS.search} className="w-3.5 h-3.5 text-[#71717a] shrink-0" />
                            <input
                                id="chat-search"
                                type="text"
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Search chats"
                                className="w-full min-w-0 bg-transparent text-xs text-[#f4f4f5] placeholder-[#71717a] focus:outline-none"
                            />
                        </div>
                    </div>

                    <nav className="flex-1 min-h-0 overflow-y-auto px-3 pt-5 pb-3 space-y-5" aria-label="Chats">
                        {groups.length === 0 && (
                            <p className="px-2 text-xs text-[#71717a] leading-relaxed">{chats.length === 0 ? "No chats yet. Describe a plugin to start your first one." : "No chats match your search."}</p>
                        )}
                        {groups.map((g) => (
                            <div key={g.name}>
                                <div className="px-2 mb-1.5 text-[11px] font-mono uppercase tracking-wider text-[#71717a]">{g.name}</div>
                                <ul className="space-y-0.5">
                                    {g.items.map((c) => (
                                        <li key={c.id} className="group relative">
                                            <button
                                                onClick={() => selectChat(c.id)}
                                                className={`w-full text-left text-[13px] pl-2.5 pr-8 py-2 rounded-md truncate transition-colors ${c.id === activeId ? 'bg-[#3A3D42] text-[#f4f4f5]' : 'text-[#a1a1aa] hover:bg-[#3A3D42]/50 hover:text-[#f4f4f5]'}`}
                                            >
                                                {c.title}
                                            </button>
                                            <button
                                                onClick={() => deleteChat(c.id)}
                                                className={`absolute right-1.5 top-1/2 -translate-y-1/2 p-1 rounded text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#26282B] transition-opacity focus:opacity-100 ${c.id === activeId ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                                                aria-label={`Delete ${c.title}`}
                                            >
                                                <Icon d={ICONS.trash} className="w-3.5 h-3.5" sw={1.75} />
                                            </button>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </nav>

                    {/* User card */}
                    <div className="border-t border-[#3A3D42] p-3 space-y-3">
                        {user.usage && <UsageMeter usage={user.usage} />}
                        <button
                            onClick={() => setShowProfile(true)}
                            className="w-full flex items-center gap-3 p-1.5 -m-1.5 rounded-lg text-left hover:bg-[#3A3D42]/50 transition-colors"
                            aria-label="Open your profile"
                        >
                            <Avatar user={user} />
                            <div className="min-w-0 flex-1">
                                <div className="text-sm font-medium text-[#f4f4f5] truncate" title={user.name}>{user.name}</div>
                                <div className="text-xs text-[#a1a1aa] truncate">{user.username ? '@' + user.username : 'Discord account'}</div>
                            </div>
                        </button>
                    </div>
                  </div>

                  {/* Collapsed rail: just the projects and the profile picture */}
                  {collapsed && (
                    <div className="hidden md:flex flex-col flex-1 min-h-0 items-center py-4 gap-2">
                        <button
                            onClick={newChat}
                            className="w-10 h-10 flex items-center justify-center bg-[#f4f4f5] hover:bg-[#e4e4e7] text-[#26282B] rounded-md transition-colors"
                            aria-label="New plugin"
                            title="New plugin"
                        >
                            <Icon d={ICONS.plus} className="w-4 h-4" sw={2.5} />
                        </button>
                        <nav className="flex-1 min-h-0 w-full overflow-y-auto flex flex-col items-center gap-1.5 py-2" aria-label="Chats">
                            {[...chats].sort((x, y) => (y.updatedAt || 0) - (x.updatedAt || 0)).map((c) => (
                                <button
                                    key={c.id}
                                    onClick={() => selectChat(c.id)}
                                    title={c.title}
                                    aria-label={c.title}
                                    className={`w-10 h-10 shrink-0 rounded-md text-sm font-semibold transition-colors ${c.id === activeId ? 'bg-[#3A3D42] text-[#f4f4f5]' : 'bg-[#26282B] border border-[#3A3D42] text-[#a1a1aa] hover:bg-[#3A3D42]/60 hover:text-[#f4f4f5]'}`}
                                >
                                    {(Array.from((c.title || '').trim())[0] || '•').toUpperCase()}
                                </button>
                            ))}
                        </nav>
                        <button onClick={() => setShowProfile(true)} className="rounded-md hover:opacity-80 transition-opacity" aria-label="Open your profile" title={user.name}>
                            <Avatar user={user} />
                        </button>
                    </div>
                  )}
                  {/* Handle on the sidebar edge: click to collapse or expand */}
                  <button
                      onClick={toggleCollapsed}
                      className="sidebar-handle hidden md:flex group absolute top-1/2 -translate-y-1/2 -right-[9px] z-[55] w-[18px] h-14 items-center justify-center rounded-full bg-[#26282B] border border-[#4b4f56] hover:bg-[#3A3D42] hover:border-[#71717a] shadow-lg shadow-black/40 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f4f4f5]"
                      aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                      aria-expanded={!collapsed}
                      title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                  >
                      <span className="handle-bar block w-[3px] h-7 rounded-full bg-[#a1a1aa] group-hover:hidden"></span>
                      <svg className="handle-chevron hidden group-hover:block w-3 h-3 text-[#f4f4f5]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                          <path d={collapsed ? 'M9 5l7 7-7 7' : 'M15 19l-7-7 7-7'} />
                      </svg>
                  </button>
                </aside>

                {/* Main chat area */}
                <main className="flex-1 min-w-0 flex flex-col relative">
                    <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none z-0"></div>

                    <header
                        className="relative z-10 h-14 px-4 sm:px-6 border-b border-[#3A3D42] bg-[#26282B]/90 backdrop-blur-md flex items-center gap-3 shrink-0"
                    >
                        <button
                            onClick={() => setSidebarOpen(true)}
                            className="md:hidden text-[#a1a1aa] hover:text-[#f4f4f5] p-1.5 rounded-md border border-[#3A3D42] bg-[#2C2E31] transition-colors"
                            aria-label="Open sidebar"
                        >
                            <Icon d={ICONS.menu} className="w-4 h-4" />
                        </button>
                        <h1 className="text-sm font-medium text-[#f4f4f5] truncate min-w-0">
                            {active ? active.title : 'New plugin'}
                        </h1>
                        <div className="ml-auto flex items-center gap-2 shrink-0">
                            {active && (
                                <button
                                    onClick={copyId}
                                    title="Copy project ID"
                                    className="hidden md:inline-flex items-center gap-1.5 text-[11px] font-mono text-[#a1a1aa] hover:text-[#f4f4f5] bg-[#2C2E31] border border-[#3A3D42] px-2.5 py-1 rounded-md transition-colors"
                                >
                                    <span className="text-[#71717a]">ID</span>
                                    {copied ? 'Copied' : active.id}
                                </button>
                            )}
                            <button onClick={() => setShowPricing(true)} className="bg-[#f4f4f5] hover:bg-[#e4e4e7] text-[#26282B] text-xs font-semibold px-3 py-1.5 rounded-md transition-colors">
                                Upgrade
                            </button>
                            <button
                                onClick={() => setShowSettings(true)}
                                className="text-[#a1a1aa] hover:text-[#f4f4f5] p-1.5 rounded-md border border-[#3A3D42] bg-[#2C2E31] hover:bg-[#3A3D42]/60 transition-colors"
                                aria-label="Settings"
                                title="Settings"
                            >
                                <Icon d={ICONS.cog} className="w-4 h-4" sw={1.75} />
                            </button>
                        </div>
                    </header>

                    <div className="relative z-10 flex-1 min-h-0 overflow-y-auto">
                        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 min-h-full flex flex-col">
                            {!active && (
                                <div className="flex-1 flex flex-col items-center justify-center text-center py-10">
                                    {missingId && (
                                        <div role="status" className="mb-8 max-w-md bg-[#2C2E31] border border-[#3A3D42] rounded-lg px-4 py-3 text-xs text-[#a1a1aa] leading-relaxed">
                                            No project found with the ID <span className="font-mono text-[#f4f4f5] break-all">{missingId}</span>. It may have been deleted, or it was created in a different browser.
                                        </div>
                                    )}
                                    <LogoMark className="h-10" />
                                    <h2 className="mt-6 text-2xl sm:text-3xl font-bold tracking-tight text-[#f4f4f5]">What do you want to build?</h2>
                                    <p className="mt-3 max-w-md text-xs sm:text-sm text-[#a1a1aa] leading-relaxed">
                                        Describe the plugin in plain English. PluginForge will turn it into a Paper plugin you can drop into your server.
                                    </p>
                                    <div className="mt-8 w-full grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
                                        {SUGGESTIONS.map((s) => (
                                            <button
                                                key={s.title}
                                                onClick={() => {
                                                    setDraft(s.text);
                                                    if (taRef.current) taRef.current.focus();
                                                }}
                                                className="bg-[#2C2E31] hover:bg-[#3A3D42]/60 border border-[#3A3D42] rounded-lg p-4 transition-colors"
                                            >
                                                <div className="text-sm font-medium text-[#f4f4f5] mb-1">{s.title}</div>
                                                <div className="text-xs text-[#a1a1aa] leading-relaxed">{s.text}</div>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {active && (
                                <div className="space-y-8">
                                    {messages.map((m, i) =>
                                        m.role === 'user'
                                            ? <UserMessage key={i} m={m} />
                                            : <AssistantMessage key={i} m={m} />
                                    )}
                                    {isPending && <TypingIndicator />}
                                    {active && !active.messages && (
                                        <p role="status" className="text-xs text-[#71717a]">Loading project…</p>
                                    )}
                                    {active && active.loadFailed && (
                                        <p role="alert" className="text-xs text-[#a1a1aa]">Couldn't load this project. Check your connection and open it again.</p>
                                    )}
                                </div>
                            )}
                            <div ref={endRef}></div>
                        </div>
                    </div>

                    {/* Composer */}
                    <div
                        className="relative z-10 px-4 sm:px-6 pt-2 pb-4 shrink-0"
                    >
                        <div className="max-w-3xl mx-auto">
                            {notice && (
                                <div role="alert" className="mb-2.5 bg-[#2C2E31] border border-[#3A3D42] rounded-lg px-3.5 py-2.5 text-xs text-[#a1a1aa] leading-relaxed">{notice}</div>
                            )}
                            <div className="bg-[#2C2E31] border border-[#3A3D42] rounded-2xl p-3 shadow-xl">
                                <div className="bg-[#26282B] border border-[#3A3D42] focus-within:border-[#71717a] rounded-xl p-2 transition-all">
                                    <textarea
                                        id="chat-input"
                                        ref={taRef}
                                        rows={1}
                                        maxLength={500}
                                        value={draft}
                                        onChange={(e) => setDraft(e.target.value)}
                                        onKeyDown={onKeyDown}
                                        placeholder={active ? 'Ask for a change, or describe another plugin...' : 'Describe the plugin you want to generate...'}
                                        className="w-full resize-none bg-transparent text-sm text-[#f4f4f5] placeholder-[#71717a] focus:outline-none px-2 py-1.5 leading-relaxed"
                                    ></textarea>
                                    <div className="flex items-center justify-between gap-3 px-2 pt-1">
                                        <span className="text-[11px] font-mono text-[#71717a]">{draft.length}/500</span>
                                        <button
                                            onClick={send}
                                            disabled={!draft.trim() || pendingId !== null}
                                            className="bg-[#f4f4f5] hover:bg-[#e4e4e7] disabled:bg-[#3A3D42] disabled:text-[#71717a] disabled:cursor-not-allowed text-[#26282B] p-2.5 rounded-lg transition-colors flex items-center justify-center shrink-0"
                                            aria-label="Send"
                                        >
                                            <Icon d={ICONS.send} className="w-4 h-4" sw={2.5} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <p className="mt-2.5 text-center text-[11px] text-[#71717a]">
                                Test generated plugins on a staging server before running them with real players.
                            </p>
                        </div>
                    </div>
                </main>
            </div>
        );
    }


    function App() {
        const [auth, setAuth] = React.useState({ status: 'loading' }); // loading | signedOut | unavailable | signedIn
        const [user, setUser] = React.useState(null);
        const [chats, setChats] = React.useState([]);
        const [activeId, setActiveId] = React.useState(null);
        const [loadingProject, setLoadingProject] = React.useState(true);
        const chatsRef = React.useRef(chats);
        chatsRef.current = chats;

        const loginMessage = (code) => {
            if (code === 'cancelled') return 'Sign in was cancelled.';
            if (code === 'failed') return "Sign in didn't work. Please try again.";
            return '';
        };

        // Open the project named in the address, fetching it if it is not in the sidebar list
        const openFromUrl = React.useCallback(async () => {
            const id = getIdFromPath();
            if (!id) { setActiveId(null); setLoadingProject(false); return; }
            if (chatsRef.current.some((c) => c.id === id)) { setActiveId(id); setLoadingProject(false); return; }
            setLoadingProject(true);
            const res = await api('/' + id, 'GET');
            if (res.ok && res.data && Array.isArray(res.data.messages)) {
                const d = res.data;
                setChats((prev) => prev.some((c) => c.id === id) ? prev : [{ id, title: d.title, updatedAt: d.updatedAt, messages: d.messages }, ...prev]);
                setActiveId(id);
            } else {
                setActiveId(null);
                if (res.status === 401) setAuth({ status: 'signedOut', message: 'Your session ended. Sign in again.' });
            }
            setLoadingProject(false);
        }, []);

        React.useEffect(() => {
            let alive = true;
            (async () => {
                const q = new URLSearchParams(window.location.search);
                const code = q.get('error');
                if (window.location.search) { try { window.history.replaceState({}, '', window.location.pathname); } catch (e) {} }

                let me = null;
                try { me = await fetch('/api/auth/me', { credentials: 'same-origin' }); } catch (e) {}
                if (!alive) return;
                if (me && me.ok) {
                    const u = await me.json();
                    const list = await api('', 'GET');
                    if (!alive) return;
                    setUser(u);
                    setChats(list.ok && list.data && Array.isArray(list.data.projects) ? list.data.projects : []);
                    setAuth({ status: 'signedIn' });
                    openFromUrl();
                } else if (code === 'setup' || (me && me.status === 503)) {
                    setAuth({ status: 'unavailable' });
                } else {
                    setAuth({ status: 'signedOut', message: loginMessage(code) });
                }
            })();
            const onPop = () => { if (chatsRef.current) openFromUrl(); };
            window.addEventListener('popstate', onPop);
            return () => { alive = false; window.removeEventListener('popstate', onPop); };
        }, []);

        const onUsage = React.useCallback((usage) => setUser((u) => (u ? { ...u, usage } : u)), []);

        const onSessionExpired = React.useCallback(() => {
            setAuth({ status: 'signedOut', message: 'Your session ended. Sign in again.' });
            setChats([]);
            setActiveId(null);
        }, []);

        // Ask the server for the latest plan and prompts, so refills and changes made by an admin show up without a refresh
        const refreshUsage = React.useCallback(async () => {
            if (document.hidden) return;
            let r;
            try { r = await fetch('/api/auth/me', { credentials: 'same-origin', cache: 'no-store' }); } catch (e) { return; }
            if (r.status === 401) return onSessionExpired();
            if (!r.ok) return;
            let d = null;
            try { d = await r.json(); } catch (e) {}
            if (d && d.usage) onUsage(d.usage);
        }, [onSessionExpired, onUsage]);

        // Check every 30 seconds while the tab is open, and straight away when the person comes back to it
        React.useEffect(() => {
            if (auth.status !== 'signedIn') return;
            const timer = setInterval(refreshUsage, 30000);
            const onVisible = () => { if (!document.hidden) refreshUsage(); };
            document.addEventListener('visibilitychange', onVisible);
            window.addEventListener('focus', refreshUsage);
            return () => {
                clearInterval(timer);
                document.removeEventListener('visibilitychange', onVisible);
                window.removeEventListener('focus', refreshUsage);
            };
        }, [auth.status, refreshUsage]);

        // And again the moment a refill is due
        const refillAt = user && user.usage ? user.usage.resetsAt : null;
        React.useEffect(() => {
            if (auth.status !== 'signedIn' || !refillAt) return;
            const wait = refillAt - Date.now() + 1500;
            if (wait > 2147483647) return;
            const timer = setTimeout(refreshUsage, Math.max(1000, wait));
            return () => clearTimeout(timer);
        }, [auth.status, refillAt, refreshUsage]);

        const onSignOut = async () => {
            try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'x-pf-request': '1' } }); } catch (e) {}
            // Switch screens first. This React setup renders after every change, so clearing the user first would crash the chat.
            setAuth({ status: 'signedOut', message: 'You have been signed out.' });
            setChats([]);
            setActiveId(null);
            navigateTo(null, true);
        };

        if (auth.status === 'loading') return <LoadingScreen />;
        if (auth.status !== 'signedIn') return <SignInScreen unavailable={auth.status === 'unavailable'} message={auth.message || ''} />;
        return (
            <ChatApp
                user={user}
                chats={chats}
                setChats={setChats}
                activeId={activeId}
                setActiveId={setActiveId}
                loadingProject={loadingProject}
                onSignOut={onSignOut}
                onSessionExpired={onSessionExpired}
                onUsage={onUsage}
            />
        );
    }

    ReactDOM.createRoot(document.getElementById('root')).render(<App />);
